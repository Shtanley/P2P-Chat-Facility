#include "list.h"

// Initialize arrays of nodes and heads
Node nodes[LIST_MAX_NUM_NODES];
List heads[LIST_MAX_NUM_HEADS];

// Initialize counters
int listNum = 0;    // Number of lists used
int nodeNum = 0;    // Number of nodes used

// Makes a new, empty list, and returns its reference on success. 
// Returns a NULL pointer on failure.
List* List_create() {
    // Check if there are any more lists to create
    if (listNum >= LIST_MAX_NUM_HEADS) {
        return NULL;
    }

    // Create new list
    List* newList = &heads[listNum];
    newList->head = NULL;
    newList->tail = NULL;
    newList->curr = NULL;
    newList->num_nodes = 0;
    newList->num_heads = listNum;
    listNum++;

    return newList;
}

// Returns the number of items in pList.
int List_count(List* pList) {
    // check if list/node is uninitialized
    if (!pList) {
        return -1;
    }
    return pList->num_nodes;
}

// Returns a pointer to the first item in pList and makes the first item the current item.
// Returns NULL and sets current item to NULL if list is empty.
void* List_first(List* pList) {
    // Check if list is empty/active
    if (pList->num_nodes == 0) {
        pList->curr = NULL;
        return NULL;
    }

    // Set current item to first item
    pList->curr = pList->head;
    return pList->curr->item;
}

// Returns a pointer to the last item in pList and makes the last item the current item.
// Returns NULL and sets current item to NULL if list is empty.
void* List_last(List* pList) {
    // Check if list is empty
    if (pList->num_nodes == 0 || !pList) {
        pList->curr = NULL;
        return NULL;
    }

    // Set current item to last item
    pList->curr = pList->tail;
    return pList->curr->item;
}

// Advances pList's current item by one, and returns a pointer to the new current item.
// If this operation advances the current item beyond the end of the pList, a NULL pointer 
// is returned and the current item is set to be beyond end of pList.
void* List_next(List* pList) {
    // Check if current item is NULL
    if (pList->curr == NULL|| !pList || !pList->curr) {
        return NULL;
    }

    // If current item is last item set current item LIST_OOB_END
    else if (pList->curr == pList->tail) {
        pList->curr = nodes + LIST_MAX_NUM_NODES + 1; 
        return NULL;
    }
    // If current is at LIST_OOB_START set current to head of list
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES + 1) {
        pList->curr = pList->head;
        if (!pList->head)
            return NULL;
        else
            return pList->head->item;
    }
    // Check if current is out of bounds of the tail
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES + 1) {
        return NULL;
    }

    // Else set current item to next item
    pList->curr = pList->curr->next;
    return pList->curr->item;
}

// Backs up pList's current item by one, and returns a pointer to the new current item. 
// If this operation backs up the current item beyond the start of the pList, a NULL pointer 
// is returned and the current item is set to be before the start of pList.
void* List_prev(List* pList) {
    // Check if current item is NULL
    if (pList->curr == NULL) {
        return NULL;
    }

    // If current item is first item set current item LIST_OOB_START
    else if (pList->curr == pList->head) {
        pList->curr = nodes + LIST_MAX_NUM_NODES;
        return NULL;
    }
    // If current is at LIST_OOB_END set current to tail of list
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES + 1) {
        pList->curr = pList->tail;
        if (!pList->tail)
            return NULL;
        else
            return pList->tail->item;
    }
    // Check if current is out of bounds of the head
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES) {
        return NULL;
    }

    // Else set current item to previous item
    pList->curr = pList->curr->prev;
    return pList->curr->item;
}

// Returns a pointer to the current item in pList.
void* List_curr(List* pList) {
    // Check if current item is NULL
    if (pList->curr == NULL || !pList || !pList->curr) {
        return NULL;
    }

    return pList->curr->item;
}

// Adds the new item to pList directly after the current item, and makes item the current item. 
// If the current pointer is before the start of the pList, the item is added at the start. If 
// the current pointer is beyond the end of the pList, the item is added at the end. 
// Returns 0 on success, -1 on failure.
int List_insert_after(List* pList, void* pItem) {
    // Check if there are any more nodes to create and if list is active or head or tail is missing
    if (nodeNum >= LIST_MAX_NUM_NODES) {
        return -1;
    }
    // Check if curr is invalid but list is not empty, return -1
    if ((!pList->curr || pList->curr == nodes + LIST_MAX_NUM_NODES + 1) && pList->num_nodes != 0) {
        return -1;
    }

    // Create new node
    Node* newNode = &nodes[nodeNum++];
    newNode->item = pItem;
    newNode->next = NULL;
    newNode->prev = NULL;
    nodeNum++;

    // Check if list is empty
    if (pList->num_nodes == 0) {
        pList->head = newNode;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }
    // Out of bounds of head
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES) {
        // Add new node to start of list
        pList->head->prev = newNode;
        newNode->next = pList->head;
        pList->head = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }
    // Out of bounds of tail
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES + 1 || pList->curr == pList->tail) {
        // Add new node to end of list
        pList->tail->next = newNode;
        newNode->prev = pList->tail;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }

    // Add new node after current node
    newNode->next = pList->curr->next;
    newNode->prev = pList->curr;
    pList->curr->next = newNode;
    pList->curr = newNode;
    pList->num_nodes++;

    // Check if new node is last node
    if (newNode->next == NULL) {
        pList->tail = newNode;
    } else {
        newNode->next->prev = newNode;
    }

    return 0;
}

// Adds item to pList directly before the current item, and makes the new item the current one. 
// If the current pointer is before the start of the pList, the item is added at the start. 
// If the current pointer is beyond the end of the pList, the item is added at the end. 
// Returns 0 on success, -1 on failure.
int List_insert_before(List* pList, void* pItem) {
    // Check if there are any more nodes to create and if list is active or head or tail is missing
    if (nodeNum >= LIST_MAX_NUM_NODES) {
        return -1;
    }

    // Create new node
    Node* newNode = &nodes[nodeNum];
    newNode->item = pItem;
    newNode->next = NULL;
    newNode->prev = NULL;
    nodeNum++;

    // Check if list is empty
    if (pList->num_nodes == 0) {
        pList->head = newNode;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }
    // Out of bounds of head
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES) {
        // Add new node to start of list
        pList->head->prev = newNode;
        newNode->next = pList->head;
        pList->head = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }
    // Out of bounds of tail
    else if (pList->curr == nodes + LIST_MAX_NUM_NODES + 1) {
        // Add new node to end of list
        pList->tail->next = newNode;
        newNode->prev = pList->tail;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }

    // Add new node before current node
    newNode->next = pList->curr;
    newNode->prev = pList->curr->prev;
    pList->curr->prev = newNode;
    pList->curr = newNode;
    pList->num_nodes++;

    // Check if new node is first node
    if (newNode->prev == NULL) {
        pList->head = newNode;
    } else {
        newNode->prev->next = newNode;
    }

    return 0;
}

// Adds item to the end of pList, and makes the new item the current one. 
// Returns 0 on success, -1 on failure.
int List_append(List* pList, void* pItem) {
    // Check if there are any more nodes to create
    if (nodeNum >= LIST_MAX_NUM_NODES) {
        return -1;
    }

    // Create new node
    Node* newNode = &nodes[nodeNum];
    newNode->item = pItem;
    newNode->next = NULL;
    newNode->prev = NULL;
    nodeNum++;

    // Check if list is empty
    if (pList->num_nodes == 0) {
        pList->head = newNode;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }

    // Add new node to end of list
    pList->tail->next = newNode;
    newNode->prev = pList->tail;
    pList->tail = newNode;
    pList->curr = newNode;
    pList->num_nodes++;

    return 0;
}

// Adds item to the front of pList, and makes the new item the current one. 
// Returns 0 on success, -1 on failure.
int List_prepend(List* pList, void* pItem) {
    // Check if there are any more nodes to create
    if (nodeNum >= LIST_MAX_NUM_NODES) {
        return -1;
    }

    // Create new node
    Node* newNode = &nodes[nodeNum];
    newNode->item = pItem;
    newNode->next = NULL;
    newNode->prev = NULL;
    nodeNum++;

    // Check if list is empty
    if (pList->num_nodes == 0) {
        pList->head = newNode;
        pList->tail = newNode;
        pList->curr = newNode;
        pList->num_nodes++;
        return 0;
    }

    // Add new node to front of list
    pList->head->prev = newNode;
    newNode->next = pList->head;
    pList->head = newNode;
    pList->curr = newNode;
    pList->num_nodes++;

    return 0;
}

// Return current item and take it out of pList. Make the next item the current one.
// If the current pointer is before the start of the pList, or beyond the end of the pList,
// then do not change the pList and return NULL.
void* List_remove(List* pList) {
    // Check if list is empty
    if (pList->num_nodes == 0) {
        return NULL;
    }

    // Check if current pointer is out of bounds
    if (pList->curr == nodes + LIST_MAX_NUM_NODES || pList->curr == nodes + LIST_MAX_NUM_NODES + 1) {
        return NULL;
    }

    // Save current item
    void* item = pList->curr->item;

    // Check if list has only one item
    if (pList->num_nodes == 1) {
        // List is now empty
        pList->head = NULL;
        pList->tail = NULL;
        pList->curr = NULL;
        pList->num_nodes--;
        return item;
    }

    // List has more than one item
    // Check if current node is first node
    if (pList->curr->prev == NULL) {
        pList->head = pList->curr->next;
        pList->head->prev = NULL;
        pList->curr = pList->head;
        pList->num_nodes--;
        return item;
    }
    // Check if current node is last node
    if (pList->curr->next == NULL) {
        pList->tail = pList->curr->prev;
        pList->tail->next = NULL;
        pList->curr = pList->tail;
        pList->num_nodes--;
        return item;
    }

    // Current node is in the middle of the list
    pList->curr->prev->next = pList->curr->next;
    pList->curr->next->prev = pList->curr->prev;
    pList->curr = pList->curr->next;
    pList->num_nodes--;

    return item;
}

// Return last item and take it out of pList. Make the new last item the current one.
// Return NULL if pList is initially empty.
void* List_trim(List* pList) {
    // Check if list is empty
    if (pList->num_nodes == 0) {
        return NULL;
    }

    // Save current item
    void* item = pList->tail->item;

    // Check if list has only one item
    if (pList->num_nodes == 1) {
        // List is now empty
        pList->head = NULL;
        pList->tail = NULL;
        pList->curr = NULL;
        pList->num_nodes--;
        return item;
    }

    // List has more than one item
    pList->tail = pList->tail->prev;
    pList->tail->next = NULL;
    pList->curr = pList->tail;
    pList->num_nodes--;

    return item;
}

// Adds pList2 to the end of pList1. The current pointer is set to the current pointer of pList1. 
// pList2 no longer exists after the operation; its head is available
// for future operations.
void List_concat(List* pList1, List* pList2) {
    // Check if pList1 is empty
    if (pList1->num_nodes == 0) {
        pList1->head = pList2->head;
        pList1->tail = pList2->tail;
        pList1->curr = pList2->curr;
        pList1->num_nodes = pList2->num_nodes;
        return;
    }

    // Check if pList2 is empty
    if (pList2->num_nodes == 0) {
        return;
    }

    // Add pList2 to end of pList1
    pList1->tail->next = pList2->head;
    pList2->head->prev = pList1->tail;
    pList1->tail = pList2->tail;
    pList1->num_nodes += pList2->num_nodes;

    // Free pList2
    pList2->head = NULL;
    pList2->tail = NULL;
    pList2->curr = NULL;
    pList2->num_nodes = 0;

    return;
}

// Delete pList. pItemFreeFn is a pointer to a routine that frees an item. 
// It should be invoked (within List_free) as: (*pItemFreeFn)(itemToBeFreedFromNode);
// pList and all its nodes no longer exists after the operation; its head and nodes are 
// available for future operations.
void List_free(List* pList, FREE_FN pItemFreeFn) {
    // Check if list is empty
    if (pList->num_nodes == 0) {
        return;
    }

    // Free all nodes in list
    Node* currNode = pList->head;
    while (currNode != NULL) {
        (*pItemFreeFn)(currNode->item);
        Node* nextNode = currNode->next;
        currNode->item = NULL;
        currNode->next = NULL;
        currNode->prev = NULL;
        currNode = nextNode;
    }

    // Reset list
    pList->head = NULL;
    pList->tail = NULL;
    pList->curr = NULL;
    pList->num_nodes = 0;
}

// Search pList, starting at the current item, until the end is reached or a match is found. 
// In this context, a match is determined by the comparator parameter. This parameter is a
// pointer to a routine that takes as its first argument an item pointer, and as its second 
// argument pComparisonArg. Comparator returns 0 if the item and comparisonArg don't match, 
// or 1 if they do. Exactly what constitutes a match is up to the implementor of comparator. 
// 
// If a match is found, the current pointer is left at the matched item and the pointer to 
// that item is returned. If no match is found, the current pointer is left beyond the end of 
// the list and a NULL pointer is returned.
// 
// If the current pointer is before the start of the pList, then start searching from
// the first node in the list (if any).
void* List_search(List* pList, COMPARATOR_FN pComparator, void* pComparisonArg) {
    // Check if list is empty
    if (pList->num_nodes == 0 || !pList) {
        return NULL;
    }

    // Check if current pointer is before start of list
    if (pList->curr == NULL || pList->curr->prev == NULL) {
        pList->curr = pList->head;
    }
    else if (pList->curr->next == NULL) {
        pList->curr = pList->tail;
    }

    // Search list
    Node* currNode = pList->curr;
    while (currNode != NULL) {
        if ((*pComparator)(currNode->item, pComparisonArg)) {
            pList->curr = currNode;
            return currNode->item;
        }
        currNode = currNode->next;
    }

    // No match found
    pList->curr = NULL;
    return NULL;
}